/*
6. Get the game titles, platforms, and sales regions along with the units sold for each
game
*/
select * from gamesales;
select * from games;

select g.GameID, g.GameTitle, s.Platform, s.SalesRegion, s.UnitsSold 
from games g
inner join gamesales s
on g.GameID = s.GameID; 