/*
1. Insert a new game with the title "Future Racing", genre "Racing", release date
"2024-10-01", and developer "Speed Studios".
*/
select * from games;
insert into games values(151, "Future Racing", "Racing" , "01-10-2024" ,"Speed Studios");
