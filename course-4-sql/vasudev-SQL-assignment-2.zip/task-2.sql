/*
2. Update the price of the game with GameID 2 on the PlayStation platform to 60.
*/
select * from gamesales where GameID = 60;
Update gamesales set Price = 60 where GameId = 60;