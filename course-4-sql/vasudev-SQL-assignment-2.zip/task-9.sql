/*
9. Retrieve game sales data for North America and Europe removing duplicate
records
*/
select distinct GameID, Platform, SalesRegion, UnitsSold
from gamesales 
where SalesRegion in ("North America", "Europe");
