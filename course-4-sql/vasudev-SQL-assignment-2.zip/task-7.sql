/*
7. Find all games, including those that have no sales data in the Game Sales table.
*/
select * from gamesales;

select g.GameID, g.GameTitle, gs.Platform, gs.SalesRegion, gs.UnitsSold 
from games g
left join gamesales gs
on g.GameID = gs.GameID
where gs.GameID Is null;
