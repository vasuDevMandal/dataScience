/*
8. Retrieve sales records where the game details are missing in the Games table.
*/

select g.GameID, g.GameTitle, g.Developer, gs.salesRegion
from games g
right join gamesales gs
on g.GameID = gs.GameID
where g.GameID is null;


SELECT gs.GameID, g.GameTitle, g.Developer, gs.SalesRegion
FROM gamesales gs
LEFT JOIN games g ON gs.GameID = g.GameID
WHERE g.GameID IS NULL;