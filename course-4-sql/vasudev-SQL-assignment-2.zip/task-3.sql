/*
3. Delete the record of the game with GameID 5 from the Game Sales table.
I set up the game ID as primarykey in both tables.
*/
select * from gamesales;
delete from gamesales where GameID = 5;
