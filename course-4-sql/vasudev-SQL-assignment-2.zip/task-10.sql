/*
10. Retrieve all game sales data from North America and Europe without removing
duplicate records.

*/
select GameID, Platform, SalesRegion, UnitsSold
from gamesales 
where SalesRegion in ("North America", "Europe");