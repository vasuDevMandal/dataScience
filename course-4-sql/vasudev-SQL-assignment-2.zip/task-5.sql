/*
5. Identify the game with the highest number of units sold in North America.
*/
select * from gamesales;

select *
from gamesales
where SalesRegion = 'North America' 
order by UnitsSold desc
limit 1;
