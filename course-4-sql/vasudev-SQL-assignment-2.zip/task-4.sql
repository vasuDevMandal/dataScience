/*
4. Calculate the total number of units sold for each game across all platforms and
regions
*/
select * from gamesales;

select GameID, sum(UnitsSold) As TotalUnitSold
from gamesales
group by GameID
order by GameID;