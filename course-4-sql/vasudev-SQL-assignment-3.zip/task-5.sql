/*
5. Show each passenger's fare and the fare of the next passenger.
*/
select first_name, last_name, fare, embark_town, 
lead(fare) OVER(partition by embark_town order by fare desc) as 'next_person_fare'
from titanic_dataset;