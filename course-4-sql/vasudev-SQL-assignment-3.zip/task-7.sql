/*
7. Write a query to rank passengers based on their fare, displaying rank for each passenger.
*/
select first_name, last_name, class, 
rank() OVER(partition by class order by fare desc) as 'Rank' 
from titanic_dataset;