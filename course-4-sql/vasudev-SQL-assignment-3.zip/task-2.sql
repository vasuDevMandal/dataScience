/*
2. Create a view to display passenger survival status, class, age, and fare.
*/


create view titanic_view as
select Passenger_No, survived, class, age, fare from titanic_dataset;