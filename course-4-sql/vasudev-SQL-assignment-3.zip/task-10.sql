/*
10. Use a CTE to calculate the average fare and find passengers who paid more than the
average.
*/

with avg_fare_cte as ( 
	select avg(fare) as avg_fare 
    from titanic_dataset
    )

select * from avg_fare_cte;


WITH prime_buyers_cte AS (
  SELECT AVG(fare) AS avg_fare
  FROM titanic_dataset
)
SELECT t.Passenger_No,t.first_name,t.last_name,t.fare
FROM titanic_dataset t,prime_buyers_cte p
WHERE t.fare > p.avg_fare;
