/*
6. Show the age of each passenger and the age of the previous passenger.
*/

select first_name,last_name, age, 
LAG(age) OVER (partition by embark_town order by fare desc) as 'previous_passanger_fare' 
from titanic_dataset;