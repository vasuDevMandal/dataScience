/*
9. Assign row numbers to passengers based on the order of their fares.
*/

select first_name, last_name, fare, class,
row_number() OVER (order by fare desc) as 'row_number'
from titanic_dataset;