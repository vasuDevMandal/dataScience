/*
3. Create a stored procedure to retrieve passengers based on a given age range
*/

DELIMITER //
CREATE PROCEDURE passenger (in personAge int)
BEGIN
select * from titanic_dataset where age = personAge;
END //
DELIMITER ;

call passenger(14);

