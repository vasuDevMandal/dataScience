/*
1. Write a query to find the name and age of the oldest passenger who survived.
*/

select  Passenger_No ,first_name , last_name , age
from titanic_dataset
where survived = 1
order by age desc 
limit 1;

