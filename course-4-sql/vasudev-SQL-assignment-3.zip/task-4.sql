/*
4. Write a query to categorize passengers based on the fare they paid: 'Low', 'Medium', or
'High'
max fare : 66662
min fare: 20068
Average fare: 43616.0952
*/
select 
		first_name, last_name, fare,
	case
		when fare > 45000 then 'high'
		when fare > 3000 then 'medium'
		else 'low'
	end as level_fare
from titanic_dataset;
