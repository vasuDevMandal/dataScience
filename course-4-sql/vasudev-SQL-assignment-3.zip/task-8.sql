/*
8. Write a query to rank passengers based on their fare, ensuring no gaps in rank
*/
select first_name, last_name, class, 
dense_rank() OVER(partition by class order by fare desc) as 'Rank' 
from titanic_dataset;
