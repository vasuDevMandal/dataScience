/* 
3. Get the top 3 longest-running movies in Hindi language sorted by IMDb score in descending order.
*/
select * from netflix_originals where Language = 'Hindi' order by IMDBScore desc limit 3;
