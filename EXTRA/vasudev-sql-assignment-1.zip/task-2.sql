/* 
2.Find the total number of Netflix Originals in each language, but only show those languages that have more
than 5 titles.
*/

select Language, count(Title) from netflix_originals group by Language;