/* 
10. Create a new table that enforces a constraint on the IMDb score to be between 0 and 10 and the runtime to
be greater than 30 minutes.
*/
CREATE TABLE netflix_validated (
    Title VARCHAR(255),
    GenreID VARCHAR(10),
    Runtime INT,
    IMDbScore DECIMAL(2,1),
    Language VARCHAR(50),
    Premiere_Date DATE,
    CHECK (IMDbScore >= 0 AND IMDbScore <= 10),
    CHECK (Runtime > 30)
);
