/* 
4. Retrieve all titles that contain the word "House" in their name and have an IMDb score greater than 6.
*/
select * from netflix_originals where Title like "%House%";