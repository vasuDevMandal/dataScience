/* 
9. List all Netflix Originals that were released in 2020, grouped by language, and show the total count of titles for each language.
*/
select Language, count(Title) as count 
from netflix_originals 
WHERE YEAR(STR_TO_DATE(Premiere_Date, '%d-%m-%Y')) = 2020
group by Language ;