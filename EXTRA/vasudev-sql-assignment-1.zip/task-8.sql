/* 
8. Retrieve the top 5 most common runtimes for Netflix Originals.
*/
select Runtime, count(Runtime) as count
from netflix_originals 
group by Runtime 
order by count desc 
limit 5; 