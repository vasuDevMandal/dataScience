/* 
7. Get the average IMDb score for each genre where the genre has at least 10 movies.
*/
select GenreID , avg(IMDBScore) from netflix_originals group by GenreID having count(*) >= 10;