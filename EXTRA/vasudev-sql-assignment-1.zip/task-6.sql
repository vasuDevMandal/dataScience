/* 
6. Find all movies that either have a runtime less than 60 minutes or an IMDb score less than 5, sorted by
Premiere Date.
*/
select * from netflix_originals where Runtime < 60 or IMDBScore < 5 order by Premiere_Date;