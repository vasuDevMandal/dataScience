/* 
1. Retrieve all Netflix Originals with an IMDb score greater than 7, runtime greater than 100 minutes, and the
language is either English or Spanish.
*/
select * from netflix_originals where IMDBScore > 7 and Runtime > 100 and Language in ("English", "Spanish");