/* 
5. Find all Netflix Originals released between the years 2018 and 2020 that are in
either English, Spanish, or Hindi.
*/
select * 
from netflix_originals 
where YEAR(STR_TO_DATE(Premiere_Date, '%d-%m-%Y')) between '2018' and '2020'
and Language in ("English","Spanish","Hindi");